import "./Footer.css";

const Footer = () => {
    return (
        <footer className="footer">
            Hugo Dandois
        </footer>
    );
}

export default Footer;
